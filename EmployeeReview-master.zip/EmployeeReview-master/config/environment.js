const developement = {
    name: 'developement',
    assets_path: './assets',
    db_path: './config/mongoose',
    passport_local_path: './config/passport-local-strategy',
    secret_key: "@%employee#@*Feedback@#14January$$**AmitSingh@1999",
    mongoose_connect:'mongodb+srv://EmployeeReview:2NpRNLA360Xy9qRw@cluster0.knr4a.mongodb.net/employee_Review?retryWrites=true&w=majority'

}


module.exports = developement;