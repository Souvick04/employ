## Description :
This is an application which allow employee to submit feedback towards each other's performance..
## Tech Stack :
 Node.Js , Mongo DB ,Css  and EJS template ,Passport Used for Authentication
 ## Packages Used :
employeereview@1.0.0
├── connect-flash@0.1.1
├── connect-mongo@4.6.0
├── cookie-parser@1.4.6
├── ejs@3.1.7
├── express-ejs-layouts@2.5.1
├── express-session@1.17.2
├── express@4.17.3
├── mongoose@6.3.0
├── nodemon@2.0.15
├── passport-local@1.0.0
├── passport@0.5.2
 ## For LocalSystem :
for this objective user can download the repository from git and then extract the folder and then type npm start command to run this .
## To Sign In :
A user need to type Email_Id , Password , And there role in organization such as : Admin or Employee
Then Click On Submit Button

## For Admin :
Admin can not register so Email Id for Admin : "admin@gmail.com" and Password : "admin" 
## Take A look :
This Project is hosted live at [Link](https://employeereview.herokuapp.com/)
Git Hub [Link](https://github.com/developeramit14jan/EmployeeReview)